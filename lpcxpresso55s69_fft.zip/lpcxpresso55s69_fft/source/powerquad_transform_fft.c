/*
 * Copyright 2018 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_debug_console.h"
#include "board.h"
#include "fsl_powerquad.h"
#include "math.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_power.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define DEMO_POWERQUAD POWERQUAD

#define FILTER_INPUT_LEN 32
#define MATH_PI          3.1415926535898
#define FLOAT_2_Q31(x)   ((int32_t)((x)*2147483648.0f))
#define FLOAT_2_Q15(x)   (int16_t) __SSAT(((int32_t)((x)*32768.0f)), 16)
#define EXAMPLE_ASSERT_TRUE(x)            \
    if (!(x))                             \
    {                                     \
        PRINTF("%s error\r\n", __func__); \
        while (1)                         \
        {                                 \
        }                                 \
    }

#if (FILTER_INPUT_LEN == 16)
#define FILTER_INPUTA_PRESCALER 4
#elif (FILTER_INPUT_LEN == 32)
#define FILTER_INPUTA_PRESCALER 5
#elif (FILTER_INPUT_LEN == 64)
#define FILTER_INPUTA_PRESCALER 6
#elif (FILTER_INPUT_LEN == 128)
#define FILTER_INPUTA_PRESCALER 7
#elif (FILTER_INPUT_LEN == 256)
#define FILTER_INPUTA_PRESCALER 8
#else
#define FILTER_INPUTA_PRESCALER 9
#endif

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static void PQ_CFFTFixed16(void);
static void PQ_CFFTFixed32(void);
static void PQ_RFFTFixed16(void);
static void PQ_RFFTFixed32(void);

/*******************************************************************************
 * Variables
 ******************************************************************************/


/*******************************************************************************
 * Code
 ******************************************************************************/

/*!
 * @brief Main function
 */
int main(void)
{
    /* Board pin, clock, debug console init */
    /* set BOD VBAT level to 1.65V */
    POWER_SetBodVbatLevel(kPOWER_BodVbatLevel1650mv, kPOWER_BodHystLevel50mv, false);
    /* attach main clock divide to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    BOARD_InitPins();
    BOARD_BootClockPLL150M();
    BOARD_InitDebugConsole();

    PRINTF("POWERQUAD transform example started\r\n");

    PQ_Init(DEMO_POWERQUAD);

    PQ_CFFTFixed16();
    PQ_CFFTFixed32();
    PQ_RFFTFixed16();
    PQ_RFFTFixed32();

    PRINTF("POWERQUAD transform example succeeded\r\n");

    while (1)
    {
    }
}

// Real FFT 16 bit
static void PQ_RFFTFixed16(void)
{
    int N = FILTER_INPUT_LEN;
    int16_t inputData[FILTER_INPUT_LEN];
    int16_t rfftResult[FILTER_INPUT_LEN * 2];

    // sample data //
    int16_t rfftRef[FILTER_INPUT_LEN * 2] = {
        100, 0,   76,  -50, 29,  -62, -1, -34,  10,   -3,   42,   -8, 51,   -47, 12, -84, -50, -70, -82, -4,  -46, 67,
        40,  82,  109, 17,  98,  -86, 5,  -147, -110, -113, -160, 0,  -110, 112, 5,  146, 98,  86,  109, -17, 40,  -83,
        -46, -68, -82, 4,   -50, 70,  12, 82,   51,   46,   42,   6,  10,   2,   -1, 33,  29,  61,  77,  49};

    for (int i = 0; i < 32; i++)
    {
        inputData[i] = 0;
    }

    inputData[0] = 10;
    inputData[1] = 30;
    inputData[2] = 10;
    inputData[3] = 30;
    inputData[4] = -50;
    inputData[5] = 70;

    pq_config_t pq_cfg;

    pq_cfg.inputAFormat   = kPQ_16Bit;
    pq_cfg.inputAPrescale = FILTER_INPUTA_PRESCALER;
    pq_cfg.inputBFormat   = kPQ_16Bit;
    pq_cfg.inputBPrescale = 0;
    pq_cfg.tmpFormat      = kPQ_16Bit;
    pq_cfg.tmpPrescale    = 0;
    pq_cfg.outputFormat   = kPQ_16Bit;
    pq_cfg.outputPrescale = 2;
    pq_cfg.tmpBase        = (uint32_t *)0xe0000000;
    pq_cfg.machineFormat  = kPQ_32Bit;
    PQ_SetConfig(DEMO_POWERQUAD, &pq_cfg);

    PQ_TransformRFFT(DEMO_POWERQUAD, N, inputData, rfftResult);
    PQ_WaitDone(DEMO_POWERQUAD);

    for (uint32_t i = 0; i < N * 2; i++)
    {
        EXAMPLE_ASSERT_TRUE(rfftRef[i] == rfftResult[i]);
        PRINTF("RFFT Result: \r\n",rfftResult[i]);
    }
}

static void PQ_RFFTFixed32(void)
{
    int N                               = FILTER_INPUT_LEN;
    int32_t inputData[FILTER_INPUT_LEN] = {0};
    int32_t rfftResult[FILTER_INPUT_LEN * 2];
    int32_t rfftRef[FILTER_INPUT_LEN * 2] = {
        100, 0,   76,  -50, 29,  -62, -1, -34,  10,   -3,   42,   -8, 51,   -47, 12, -84, -50, -70, -82, -4,  -46, 67,
        40,  82,  109, 17,  98,  -86, 5,  -147, -110, -113, -160, 0,  -110, 112, 5,  146, 98,  86,  109, -17, 40,  -83,
        -46, -68, -82, 4,   -50, 70,  12, 82,   51,   46,   42,   6,  10,   2,   -1, 33,  29,  61,  77,  49};

    inputData[0] = 10;
    inputData[1] = 30;
    inputData[2] = 10;
    inputData[3] = 30;
    inputData[4] = -50;
    inputData[5] = 70;

    pq_config_t pq_cfg;

    pq_cfg.inputAFormat   = kPQ_32Bit;
    pq_cfg.inputAPrescale = FILTER_INPUTA_PRESCALER;
    pq_cfg.inputBFormat   = kPQ_32Bit;
    pq_cfg.inputBPrescale = 0;
    pq_cfg.tmpFormat      = kPQ_32Bit;
    pq_cfg.tmpPrescale    = 0;
    pq_cfg.outputFormat   = kPQ_32Bit;
    pq_cfg.outputPrescale = 2;
    pq_cfg.tmpBase        = (uint32_t *)0xe0000000;
    pq_cfg.machineFormat  = kPQ_32Bit;
    PQ_SetConfig(DEMO_POWERQUAD, &pq_cfg);

    PQ_TransformRFFT(DEMO_POWERQUAD, N, inputData, rfftResult);
    PQ_WaitDone(DEMO_POWERQUAD);

    for (uint32_t i = 0; i < N * 2; i++)
    {
        EXAMPLE_ASSERT_TRUE(rfftRef[i] == rfftResult[i]);
    }
}

static void PQ_CFFTFixed16(void)
{
    int N                                   = FILTER_INPUT_LEN;
    int16_t inputData[FILTER_INPUT_LEN * 2] = {0};
    int16_t cfftResult[FILTER_INPUT_LEN * 2];
    int16_t cfftRef[FILTER_INPUT_LEN * 2] = {
        100, 0,   76,  -50, 29,  -62, -1, -34,  10,   -3,   42,   -8, 51,   -47, 12, -84, -50, -70, -82, -4,  -46, 67,
        40,  82,  109, 17,  98,  -86, 5,  -147, -110, -113, -160, 0,  -110, 112, 5,  146, 98,  86,  109, -17, 40,  -83,
        -46, -68, -82, 4,   -50, 70,  12, 82,   51,   46,   42,   6,  10,   2,   -1, 33,  29,  61,  77,  49};

    inputData[0]  = 10;
    inputData[2]  = 30;
    inputData[4]  = 10;
    inputData[6]  = 30;
    inputData[8]  = -50;
    inputData[10] = 70;

    pq_config_t pq_cfg;

    pq_cfg.inputAFormat   = kPQ_16Bit;
    pq_cfg.inputAPrescale = FILTER_INPUTA_PRESCALER;
    pq_cfg.inputBFormat   = kPQ_16Bit;
    pq_cfg.inputBPrescale = 0;
    pq_cfg.tmpFormat      = kPQ_16Bit;
    pq_cfg.tmpPrescale    = 0;
    pq_cfg.outputFormat   = kPQ_16Bit;
    pq_cfg.outputPrescale = 0;
    pq_cfg.tmpBase        = (uint32_t *)0xe0000000;
    pq_cfg.machineFormat  = kPQ_32Bit;
    PQ_SetConfig(DEMO_POWERQUAD, &pq_cfg);

    PQ_TransformCFFT(DEMO_POWERQUAD, N, inputData, cfftResult);
    PQ_WaitDone(DEMO_POWERQUAD);

    for (uint32_t i = 0; i < N * 2; i++)
    {
        EXAMPLE_ASSERT_TRUE(cfftRef[i] == cfftResult[i]);
    }
}

static void PQ_CFFTFixed32(void)
{
    int N                                   = FILTER_INPUT_LEN;
    int32_t inputData[FILTER_INPUT_LEN * 2] = {0};
    int32_t cfftResult[FILTER_INPUT_LEN * 2];
    int32_t cfftRef[FILTER_INPUT_LEN * 2] = {
        100, 0,   76,  -50, 29,  -62, -1, -34,  10,   -3,   42,   -8, 51,   -47, 12, -84, -50, -70, -82, -4,  -46, 67,
        40,  82,  109, 17,  98,  -86, 5,  -147, -110, -113, -160, 0,  -110, 112, 5,  146, 98,  86,  109, -17, 40,  -83,
        -46, -68, -82, 4,   -50, 70,  12, 82,   51,   46,   42,   6,  10,   2,   -1, 33,  29,  61,  77,  49};

    inputData[0]  = 10;
    inputData[2]  = 30;
    inputData[4]  = 10;
    inputData[6]  = 30;
    inputData[8]  = -50;
    inputData[10] = 70;

    pq_config_t pq_cfg;

    pq_cfg.inputAFormat   = kPQ_32Bit;
    pq_cfg.inputAPrescale = FILTER_INPUTA_PRESCALER;
    pq_cfg.inputBFormat   = kPQ_32Bit;
    pq_cfg.inputBPrescale = 0;
    pq_cfg.tmpFormat      = kPQ_32Bit;
    pq_cfg.tmpPrescale    = 0;
    pq_cfg.outputFormat   = kPQ_32Bit;
    pq_cfg.outputPrescale = 0;
    pq_cfg.tmpBase        = (uint32_t *)0xe0000000;
    pq_cfg.machineFormat  = kPQ_32Bit;
    PQ_SetConfig(DEMO_POWERQUAD, &pq_cfg);

    PQ_TransformCFFT(DEMO_POWERQUAD, N, inputData, cfftResult);
    PQ_WaitDone(DEMO_POWERQUAD);

    for (uint32_t i = 0; i < N * 2; i++)
    {
        EXAMPLE_ASSERT_TRUE(cfftRef[i] == cfftResult[i]);
    }
}
