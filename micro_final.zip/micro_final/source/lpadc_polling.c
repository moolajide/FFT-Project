/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2020 NXP
 * All rights reserved.
 *
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_debug_console.h"
#include "board.h"
#include "fsl_lpadc.h"
#include "fsl_powerquad.h"
#include "math.h"

#include "clock_config.h"
#include "fsl_inputmux.h"
#include "pin_mux.h"
#include "fsl_power.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define LPADC_BASE                  ADC0
#define LPADC_USER_CHANNEL          0U
#define LPADC_USER_CMDID            1U /* CMD1 */
#define LPADC_VREF_SOURCE           kLPADC_ReferenceVoltageAlt2


#define FILTER_INPUT_LEN 512
#define MATH_PI          3.1415926535898
#define FLOAT_2_Q31(x)   ((int32_t)((x)*2147483648.0f))
#define FLOAT_2_Q15(x)   (int16_t) __SSAT(((int32_t)((x)*32768.0f)), 16)


#if (FILTER_INPUT_LEN == 16)
#define FILTER_INPUTA_PRESCALER 4
#elif (FILTER_INPUT_LEN == 32)
#define FILTER_INPUTA_PRESCALER 5
#elif (FILTER_INPUT_LEN == 64)
#define FILTER_INPUTA_PRESCALER 6
#elif (FILTER_INPUT_LEN == 128)
#define FILTER_INPUTA_PRESCALER 7
#elif (FILTER_INPUT_LEN == 256)
#define FILTER_INPUTA_PRESCALER 8
#else
#define FILTER_INPUTA_PRESCALER 9
#endif
/*******************************************************************************
 * Prototypes
 ******************************************************************************/
static void PQ_RFFTFixed32(void);
/*******************************************************************************
 * Variables
 ******************************************************************************/

const uint32_t g_LpadcFullRange   = 4096U;
const uint32_t g_LpadcResultShift = 3U;
const uint16_t sample_length = 512;
const uint32_t bin = 72000/512;

int N = FILTER_INPUT_LEN;
int16_t inputData[FILTER_INPUT_LEN] = {0};
int32_t rfftResult[FILTER_INPUT_LEN * 2];
int32_t sums[FILTER_INPUT_LEN] = {0};
int32_t max = 0;
int32_t max_index = 0;
uint16_t SampleValues[FILTER_INPUT_LEN];
/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Main function
 */
int main(void)
{
    lpadc_config_t mLpadcConfigStruct;
    lpadc_conv_trigger_config_t mLpadcTriggerConfigStruct;
    lpadc_conv_command_config_t mLpadcCommandConfigStruct;
    lpadc_conv_result_t mLpadcResultConfigStruct;


    /* set BOD VBAT level to 1.65V */
    POWER_SetBodVbatLevel(kPOWER_BodVbatLevel1650mv, kPOWER_BodHystLevel50mv, false);
    /* attach 12 MHz clock to FLEXCOMM0 (debug console) */
    CLOCK_AttachClk(BOARD_DEBUG_UART_CLK_ATTACH);

    BOARD_InitPins();
    BOARD_BootClockPLL150M();
    BOARD_InitDebugConsole();

    CLOCK_SetClkDiv(kCLOCK_DivAdcAsyncClk, 8U, true);
    CLOCK_AttachClk(kMAIN_CLK_to_ADC_CLK);

    /* Disable LDOGPADC power down */
    POWER_DisablePD(kPDRUNCFG_PD_LDOGPADC);

    LPADC_GetDefaultConfig(&mLpadcConfigStruct);
    mLpadcConfigStruct.enableAnalogPreliminary = true;
    mLpadcConfigStruct.referenceVoltageSource = LPADC_VREF_SOURCE;
    LPADC_Init(LPADC_BASE, &mLpadcConfigStruct);

    /* Set conversion CMD configuration. */
    LPADC_GetDefaultConvCommandConfig(&mLpadcCommandConfigStruct);
    mLpadcCommandConfigStruct.channelNumber = LPADC_USER_CHANNEL;
    LPADC_SetConvCommandConfig(LPADC_BASE, LPADC_USER_CMDID, &mLpadcCommandConfigStruct);

    /* Set trigger configuration. */
    LPADC_GetDefaultConvTriggerConfig(&mLpadcTriggerConfigStruct);
    mLpadcTriggerConfigStruct.targetCommandId       = LPADC_USER_CMDID;
    mLpadcTriggerConfigStruct.enableHardwareTrigger = false;
    LPADC_SetConvTriggerConfig(LPADC_BASE, 0U, &mLpadcTriggerConfigStruct); /* Configurate the trigger0. */


    // Gather 512 samples
    for(int i = 0; i != sample_length-1; i++) {
    	LPADC_DoSoftwareTrigger(LPADC_BASE, 1U); /* 1U is trigger0 mask. */
    	while (!LPADC_GetConvResult(LPADC_BASE, &mLpadcResultConfigStruct, 0U)) {
    			}
    	SampleValues[i] = ((mLpadcResultConfigStruct.convValue) >> g_LpadcResultShift)*10*3.3/g_LpadcFullRange;;
    }
    PQ_Init(POWERQUAD);

    PQ_RFFTFixed32();
    PRINTF("Max value from FFT is %d and it's bin index is %d\r\n", max, max_index);
    PRINTF("The frequency of the input signal is approixmately %d Hz\r\n", max_index*bin);
    while(1)
    {}
}
static void PQ_RFFTFixed32(void)
{

    pq_config_t pq_cfg;

    pq_cfg.inputAFormat   = kPQ_16Bit;
    pq_cfg.inputAPrescale = 9;
    pq_cfg.inputBFormat   = kPQ_16Bit;
    pq_cfg.inputBPrescale = 0;
    pq_cfg.tmpFormat      = kPQ_32Bit;
    pq_cfg.tmpPrescale    = 0;
    pq_cfg.outputFormat   = kPQ_32Bit;
    pq_cfg.outputPrescale = 2;
    pq_cfg.tmpBase        = (uint32_t *)0xe0000000;
    pq_cfg.machineFormat  = kPQ_32Bit;
    PQ_SetConfig(POWERQUAD, &pq_cfg);

    PQ_TransformRFFT(POWERQUAD, N, SampleValues, rfftResult);
    PQ_WaitDone(POWERQUAD);
    uint32_t j = 0;
    for (uint32_t i = 0; i < 512; i+=2)
    {
        sums[j] = abs(rfftResult[i]) + abs(rfftResult[i+1]);
        j++;
    }

    for (uint32_t i = 1; i < N; ++i)
    {
    	if(sums[i] > max) {
    		max = sums[i];
    		max_index = i;
    	}
    }
}
